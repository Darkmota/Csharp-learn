﻿namespace 主菜单
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.运算ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.addop = new System.Windows.Forms.ToolStripMenuItem();
            this.减ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.乘ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.加ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.减ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.乘ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.除ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(44, 43);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(228, 42);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 21);
            this.textBox2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "数1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(198, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "数2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(95, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "结果";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(140, 121);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 21);
            this.textBox3.TabIndex = 5;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.运算ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(379, 25);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 运算ToolStripMenuItem
            // 
            this.运算ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.addop,
            this.减ToolStripMenuItem,
            this.乘ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.除ToolStripMenuItem});
            this.运算ToolStripMenuItem.Name = "运算ToolStripMenuItem";
            this.运算ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.运算ToolStripMenuItem.Text = "运算";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(184, 6);
            // 
            // addop
            // 
            this.addop.Name = "addop";
            this.addop.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.A)));
            this.addop.Size = new System.Drawing.Size(187, 22);
            this.addop.Text = "加 (&A)";
            this.addop.Click += new System.EventHandler(this.加ToolStripMenuItem_Click);
            // 
            // 减ToolStripMenuItem
            // 
            this.减ToolStripMenuItem.Name = "减ToolStripMenuItem";
            this.减ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.减ToolStripMenuItem.Text = "减";
            // 
            // 乘ToolStripMenuItem
            // 
            this.乘ToolStripMenuItem.Name = "乘ToolStripMenuItem";
            this.乘ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.乘ToolStripMenuItem.Text = "乘";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(184, 6);
            // 
            // 除ToolStripMenuItem
            // 
            this.除ToolStripMenuItem.Name = "除ToolStripMenuItem";
            this.除ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.除ToolStripMenuItem.Text = "除";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.加ToolStripMenuItem,
            this.减ToolStripMenuItem1,
            this.乘ToolStripMenuItem1,
            this.toolStripSeparator2,
            this.除ToolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(89, 98);
            // 
            // 加ToolStripMenuItem
            // 
            this.加ToolStripMenuItem.Name = "加ToolStripMenuItem";
            this.加ToolStripMenuItem.Size = new System.Drawing.Size(88, 22);
            this.加ToolStripMenuItem.Text = "加";
            this.加ToolStripMenuItem.Click += new System.EventHandler(this.加ToolStripMenuItem_Click);
            // 
            // 减ToolStripMenuItem1
            // 
            this.减ToolStripMenuItem1.Name = "减ToolStripMenuItem1";
            this.减ToolStripMenuItem1.Size = new System.Drawing.Size(88, 22);
            this.减ToolStripMenuItem1.Text = "减";
            // 
            // 乘ToolStripMenuItem1
            // 
            this.乘ToolStripMenuItem1.Name = "乘ToolStripMenuItem1";
            this.乘ToolStripMenuItem1.Size = new System.Drawing.Size(88, 22);
            this.乘ToolStripMenuItem1.Text = "乘";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(85, 6);
            // 
            // 除ToolStripMenuItem1
            // 
            this.除ToolStripMenuItem1.Name = "除ToolStripMenuItem1";
            this.除ToolStripMenuItem1.Size = new System.Drawing.Size(88, 22);
            this.除ToolStripMenuItem1.Text = "除";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 195);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "计算";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 运算ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addop;
        private System.Windows.Forms.ToolStripMenuItem 减ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 乘ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 除ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 加ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 减ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 乘ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem 除ToolStripMenuItem1;
    }
}

