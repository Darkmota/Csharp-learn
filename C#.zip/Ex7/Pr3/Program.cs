﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Pr3
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread a = new Thread(delegate () { for (int i = 0; i < 100; i++) Console.Write("A"); });
            Thread b = new Thread(delegate () { for (int i = 0; i < 100; i++) Console.Write("B"); });
            Thread c = new Thread(delegate () { for (int i = 0; i < 100; i++) Console.Write("C"); });

            a.Priority = ThreadPriority.AboveNormal;
            b.Priority = ThreadPriority.Normal;
            c.Priority = ThreadPriority.BelowNormal;

            a.Start();
            b.Start();
            c.Start();

            a.Join();
            b.Join();
            c.Join();
            Console.Read();
        }
    }
}
