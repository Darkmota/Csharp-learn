﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pr1
{
    public partial class Form1 : Form
    {
        private Thread _thread = null;

        public Form1()
        {
            InitializeComponent();
            Form.CheckForIllegalCrossThreadCalls = false;

        }


        private void button1_Click(object sender, EventArgs e)
        {
            CreateThread();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SuspendThread();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ResumeThread();
        }

        private void CreateThread()
        {
            try
            {
                if (_thread == null)
                {
                    _thread = new Thread(DoCalculation);
                    _thread.Start();
                }
            }
            catch
            {

            }
        }

        private void SuspendThread()
        {
            try
            {
                if (_thread != null)
                {
                    _thread.Suspend();
                }
            }
            catch
            {

            }
        }

        private void ResumeThread()
        {
            try
            {
                if (_thread != null)
                {
                    _thread.Resume();
                }
            }
            catch
            {

            }
        }

        private void DoCalculation()
        {
            for (int i = 0; i < 20; i++)
            {
                textBox1.Text += "Message " + i + ": Hello";
                Thread.Sleep(300);
            }
        }
    }
}
