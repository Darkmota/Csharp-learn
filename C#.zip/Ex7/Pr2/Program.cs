﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Pr2
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread t = new Thread(delegate() { });
            Console.WriteLine("唯一标识符："+t.ManagedThreadId);
            Console.WriteLine("线程名称：" + t.Name);
            Console.WriteLine("线程状态：" + t.ThreadState);
            Console.WriteLine("线程优先级：" + t.Priority);
            Console.WriteLine("线程是否为后台程序" + t.IsBackground);
            t.Abort();
            Console.Read();
        }
    }
}
