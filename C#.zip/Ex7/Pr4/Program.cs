﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Pr4
{
    class Program
    {
        // ran.Next(101)

        static void Main(string[] args)
        {
            Thread A = new Thread(TaskX);
            A.Start();
            A.Join();
            Console.Read();
        }

        private static void TaskX()
        {
            Random ran = new Random();
            int i, j;
            for (i = 0; i < 10; i++)
            {
                int threadNumber = ran.Next(5);
                Thread[] ts = new Thread[threadNumber];
                for (j = 0; j < threadNumber; j++)
                    ts[j] = new Thread(()=>print(j));
                for (j = 0; j < threadNumber; j++)
                    ts[j].Start();
                for (j = 0; j < threadNumber; j++)
                    ts[j].Join();
                Console.WriteLine("------------------------");
                Console.WriteLine("第" + i + "次循环结束！");
                Console.WriteLine("本次循环生成线程数：" + threadNumber);
                Console.WriteLine("------------------------");
            }
        }
        private static void print(int num)
        {
            Random ran = new Random();
            int runTime = ran.Next(200) + 100;
            for (int k = 0; k < runTime; k++)
            {
                Console.Write(num);
                Thread.Sleep(1);
            }
        }
    }
}
