﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr3
{   
    class Sort
    {
        const int l= 100000;
        private int[] arr = new int[l];
        private Stopwatch sw = new Stopwatch();

        private void BubbleSort()
        {
            int i, j;
            for(i=0;i<l;i++)
                for(j =i+1;j<l;j++)
                    if (arr[i] < arr[j])
                    {
                        int t = arr[i];
                        arr[i] = arr[j];
                        arr[j] = t;
                    }
                        
        }
        private void SelectSort()
        {
            for (int i = 0; i < l - 1; i++)
            {
                int min = i;
                int temp = arr[i];
                for (int j = i + 1; j < l; j++)
                {
                    if (arr[j] < temp)
                    {
                        min = j;
                        temp = arr[j];
                    }
                }
                if (min != i)
                {
                    int t = arr[min];
                    arr[min] = arr[i];
                    arr[i] = t;
                }
                    
            }
        }

        private void InsertSort()
        {
            {
                int temp;
                for (int i = 1; i < l; i++)
                {
                    temp = arr[i];
                    for (int j = i - 1; j >= 0; j--)
                    {
                        if (arr[j] > temp)
                        {
                            arr[j + 1] = arr[j];
                            if (j == 0)
                            {
                                arr[0] = temp;
                                break;
                            }
                        }
                        else
                        {
                            arr[j + 1] = temp;
                            break;
                        }
                    }
                }
            }
        }
        private void Ranarr()
        {
            Random ran = new Random();
            int i;
            for (i = 0; i < l; i++)
                arr[i] = ran.Next(l + 1);
        }
        private void before_sort()
        {
            Ranarr();
            sw.Start();
        }
        private void end_sort(String SortType)
        {
            sw.Stop();
            Console.WriteLine("{0}总共花费{1}ms.", SortType, sw.Elapsed.TotalMilliseconds);
            sw.Reset();
        }
        public void run()
        {
            before_sort();
            BubbleSort();
            end_sort("冒泡排序");

            before_sort();
            InsertSort();
            end_sort("插入排序");

            before_sort();
            SelectSort();
            end_sort("选择排序");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            new Sort().run();
            Console.ReadKey();
        }
    }
}
