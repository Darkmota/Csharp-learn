﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr4
{
    abstract class Equation
    {
        protected double a, b, c, d;
        protected abstract void input();
        public abstract void run();
    }
    class Linear : Equation
    {
        protected override void input()
        {
            Console.WriteLine("形如ax+b=0式子，请依次输入a、b，并以换行符分隔：");
            a = Convert.ToDouble(Console.ReadLine());
            b = Convert.ToDouble(Console.ReadLine());
        }
        public override void run()
        {
            input();
            double x = (-b) / a;
            Console.WriteLine("x : {0}", x);
        }
    }
    class Quadratic : Equation
    {
        protected override void input()
        {
            Console.WriteLine("形如ax^2+bx+c=0式子，请依次输入a、b、c，并以换行符分隔：");
            a = Convert.ToDouble(Console.ReadLine());
            b = Convert.ToDouble(Console.ReadLine());
            c = Convert.ToDouble(Console.ReadLine());
        }
        public override void run()
        {
            input();
            double x1 = (-b - Math.Sqrt(b * b - 4 * a * c)) / (2 * a);
            double x2 = (-b + Math.Sqrt(b * b - 4 * a * c)) / (2 * a);
            if (b * b - 4 * a * c > 0)
                Console.WriteLine("x1={0} ,x2={1} ", x1, x2);
            else if (b * b - 4 * a * c < 0)
                Console.WriteLine("错误，无解");
            else
            {
                x1 = x2 = -b / (2 * a);
                Console.WriteLine("x1=x2={0}", x1);
            }
        }
    }
    class Cubic : Equation
    {
        protected override void input()
        {
            Console.WriteLine("形如ax^3+bx^2+cx+d=0式子，请依次输入a、b、c、d，并以换行符分隔：");
            a = Convert.ToDouble(Console.ReadLine());
            b = Convert.ToDouble(Console.ReadLine());
            c = Convert.ToDouble(Console.ReadLine());
            d = Convert.ToDouble(Console.ReadLine());
        }
        public override void run()
        {
            input();

            double x1, x2, y;
            x1 = (-2 * b - Math.Sqrt(4 * b * b - 12 * a * c)) / (6 * a);
            x2 = (-2 * b + Math.Sqrt(4 * b * b - 12 * a * c)) / (6 * a);
            if (x1 > x2)
            {
                y = x1;
                x1 = x2;
                x2 = y;
            }
            Console.WriteLine("x1={0}  x2={1}  x3={2}", X(-100, x1), X(x1, x2), X(x2, 100));
        }
        private double F(double x)
        {
            return a * x * x * x + b * x * x + c * x + d;
        }
        private double X(double x1, double x2)
        {
            double mid;
            while (true)
            {
                mid = (x1 + x2) / 2;
                if (Math.Abs(x1 - x2) < 1E-5) return mid;
                else
                {
                    if (F(mid) == 0) return mid;
                    else if (F(x1) * F(mid) < 0) x2 = mid;
                    else x1 = mid;
                }
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入您想计算什么方程：");
            Console.WriteLine("(1)一元一次方程组");
            Console.WriteLine("(2)一元二次方程组");
            Console.WriteLine("(3)一元三次方程组");

            Equation e;

            string s = Console.ReadLine();
            if (s == "1")
                e = new Linear();
            else if (s == "2")
                e = new Quadratic();
            else
                e = new Cubic();

            e.run();
            Console.ReadKey();
        }

    }
}
