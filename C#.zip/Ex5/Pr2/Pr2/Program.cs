﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr2
{
    abstract class Shape
    {
        protected int w, h, r;
        protected abstract void S();
        protected abstract void C();
        protected abstract void input();
        public void run() {
            input();
            S();
            C();
        }
    }
    class Rectangle : Shape
    {

        protected override void S()
        {
            Console.WriteLine("面积为：" + w * h);
        }
        protected override void C() { 

            Console.WriteLine("周长为："+Convert.ToString(w+h+w+h));
        
        }
        protected override void input()
        {
            Console.WriteLine("请输入矩形的长和宽，并以换行符分隔：");
            w = Convert.ToInt32(Console.ReadLine());
            h = Convert.ToInt32(Console.ReadLine());
        }
    }
    class Circular: Shape
    {

        protected override void S()
        {
            Console.WriteLine("面积为：" + Math.PI*r*r);
        }
        protected override void C()
        {
            Console.WriteLine("周长为：" + 2 * Math.PI * r);

        }
        protected override void input()
        {
            Console.WriteLine("请输入圆形的半径：");
            r = Convert.ToInt32(Console.ReadLine());

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入您想要交互的形状：");
            Console.WriteLine("(1)矩形");
            Console.WriteLine("(2)圆形");

            Shape s;

            if (Console.ReadLine() == "1")
                s = new Rectangle();
            else
                s = new Circular();
            s.run();
            Console.ReadKey();
        }
    }
}
