﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pr4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String filename = textBox1.Text;
            if (filename == "")
            {
                MessageBox.Show("请输入文件名！");
                return;
            }
            if (File.Exists(filename))
            {
                MessageBox.Show("该文件已存在！");
                return;
            }
            String content = textBox2.Text;

            StreamWriter sw = new StreamWriter(filename, true);
            //向创建的文件中写入内容
            sw.WriteLine(content);
            //关闭当前文件写入流
            sw.Close();
            textBox2.Text = string.Empty;
        }
    }
}
