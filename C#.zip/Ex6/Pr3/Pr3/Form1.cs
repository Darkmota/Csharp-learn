﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pr3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void load_list_directory()
        {
            listBox1.Items.Clear();
            DirectoryInfo TheFolder = new DirectoryInfo("file");
            foreach (FileInfo NextFile in TheFolder.GetFiles())
                listBox1.Items.Add(NextFile.Name);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            if (!Directory.Exists("file"))
                Directory.CreateDirectory("file");
            if (!Directory.Exists("file2"))
                Directory.CreateDirectory("file2");
            load_list_directory();

            Console.Write(comboBox1.SelectedText);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String filename = textBox1.Text;
            if (filename == "")
            {
                MessageBox.Show("请输入文件名！");
                return;
            }
            String filesuffix = comboBox1.SelectedItem.ToString();
            if (filesuffix == "")
            {
                MessageBox.Show("请选择文件后缀！");
                return;
            }
            String filepath = "file2/" + filename + filesuffix;
            if (File.Exists(filepath))
            {
                MessageBox.Show("该文件已存在！");
                return;
            }
            File.Create(filepath);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String filename = listBox1.SelectedItem.ToString();
            if (filename == "")
            {
                MessageBox.Show("请先选择文件！");
                return;
            }
            String filepath = "file/" + filename;
            File.Delete(filepath);
            load_list_directory();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String origin = listBox1.SelectedItem.ToString();
            if (origin == "")
            {
                MessageBox.Show("请先选择文件！");
                return;
            }

            String target = textBox1.Text;
            if (target == "")
            {
                MessageBox.Show("请输入文件名！");
                return;
            }
            String targetsuffix = comboBox1.SelectedItem.ToString();
            if (targetsuffix == "")
            {
                MessageBox.Show("请选择文件后缀！");
                return;
            }

            String origin_path = "file/" + origin;
            String target_path = "file2/" + target + targetsuffix;

            if (File.Exists(target_path))
            {
                MessageBox.Show("该文件已存在！");
                return;
            }

            File.Move(origin_path, target_path);
            load_list_directory();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            String origin = listBox1.SelectedItem.ToString();
            if (origin == "")
            {
                MessageBox.Show("请先选择文件！");
                return;
            }

            String target = textBox1.Text;
            if (target == "")
            {
                MessageBox.Show("请输入文件名！");
                return;
            }
            String targetsuffix = comboBox1.SelectedItem.ToString();
            if (targetsuffix == "")
            {
                MessageBox.Show("请选择文件后缀！");
                return;
            }

            String origin_path = "file/" + origin;
            String target_path = "file2/" + target + targetsuffix;

            if (File.Exists(target_path))
            {
                MessageBox.Show("该文件已存在！");
                return;
            }

            File.Copy(origin_path,target_path);

        }
    }
}
