﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pr2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String path = textBox1.Text;
            if (path == "")
            {
                MessageBox.Show("文件夹不能为空！");
                return;
            }
            if (!Directory.Exists(path))
            {
                MessageBox.Show("文件夹不存在！");
                return;
            }

            DirectoryInfo TheFolder = new DirectoryInfo(path);
            //遍历文件夹
            foreach (DirectoryInfo NextFolder in TheFolder.GetDirectories())
                listBox1.Items.Add(NextFolder.Name);
            //遍历文件
            foreach (FileInfo NextFile in TheFolder.GetFiles())
                listBox1.Items.Add(NextFile.Name);
        }
    }
}
