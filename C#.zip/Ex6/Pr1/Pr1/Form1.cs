﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pr1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String path = textBox1.Text;
            if (path == "")
                MessageBox.Show("文件夹名称不能为空！");
            if (radioButton1.Checked)
            {
                //删除目录
                if (!Directory.Exists(path))
                    MessageBox.Show("此文件夹不存在！");
                else
                    Directory.Delete(path);
            }
            else
            {
                if (Directory.Exists(path))
                    MessageBox.Show("此文件夹已存在！");
                else
                    Directory.CreateDirectory(path);
            }
        }
    }
}
