﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pr5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (!Directory.Exists("file"))
            {
                Directory.CreateDirectory("file");
            }
            DirectoryInfo TheFolder = new DirectoryInfo("file");
            //遍历文件
            foreach (FileInfo NextFile in TheFolder.GetFiles())
                comboBox1.Items.Add(NextFile.Name);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            String filename = comboBox1.SelectedItem.ToString();

            textBox1.Text = string.Empty;
            StreamReader sr = new StreamReader("file/"+filename);
            //调用ReadToEnd方法读取选中文件的全部内容
            textBox1.Text = sr.ReadToEnd();
            //关闭当前文件读取流
            sr.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String filename = comboBox1.SelectedItem.ToString();

            StreamWriter sw = new StreamWriter("file/"+filename, true);
            //向创建的文件中写入内容
            sw.WriteLine(textBox1.Text);
            //关闭当前文件写入流
            sw.Close();
        }
    }
}
