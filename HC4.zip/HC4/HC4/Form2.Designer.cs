﻿namespace HC4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.backspace = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.n1 = new System.Windows.Forms.Button();
            this.n2 = new System.Windows.Forms.Button();
            this.n3 = new System.Windows.Forms.Button();
            this.n4 = new System.Windows.Forms.Button();
            this.n5 = new System.Windows.Forms.Button();
            this.n6 = new System.Windows.Forms.Button();
            this.n7 = new System.Windows.Forms.Button();
            this.n8 = new System.Windows.Forms.Button();
            this.n9 = new System.Windows.Forms.Button();
            this.n0 = new System.Windows.Forms.Button();
            this.point = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.minus = new System.Windows.Forms.Button();
            this.time = new System.Windows.Forms.Button();
            this.div = new System.Windows.Forms.Button();
            this.eq = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Consolas", 20F);
            this.textBox1.Location = new System.Drawing.Point(13, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(318, 39);
            this.textBox1.TabIndex = 0;
            // 
            // backspace
            // 
            this.backspace.Font = new System.Drawing.Font("Consolas", 18F);
            this.backspace.Location = new System.Drawing.Point(175, 57);
            this.backspace.Name = "backspace";
            this.backspace.Size = new System.Drawing.Size(156, 45);
            this.backspace.TabIndex = 1;
            this.backspace.Text = "←";
            this.backspace.UseVisualStyleBackColor = true;
            this.backspace.Click += new System.EventHandler(this.backspace_Click);
            // 
            // clear
            // 
            this.clear.Font = new System.Drawing.Font("Consolas", 18F);
            this.clear.ForeColor = System.Drawing.Color.Red;
            this.clear.Location = new System.Drawing.Point(13, 57);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(156, 45);
            this.clear.TabIndex = 2;
            this.clear.Text = "CLEAR";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // n1
            // 
            this.n1.Font = new System.Drawing.Font("Consolas", 30F);
            this.n1.Location = new System.Drawing.Point(13, 108);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(75, 75);
            this.n1.TabIndex = 3;
            this.n1.Text = "1";
            this.n1.UseVisualStyleBackColor = true;
            this.n1.Click += new System.EventHandler(this.n1_Click);
            // 
            // n2
            // 
            this.n2.Font = new System.Drawing.Font("Consolas", 30F);
            this.n2.Location = new System.Drawing.Point(94, 108);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(75, 75);
            this.n2.TabIndex = 4;
            this.n2.Text = "2";
            this.n2.UseVisualStyleBackColor = true;
            this.n2.Click += new System.EventHandler(this.n2_Click);
            // 
            // n3
            // 
            this.n3.Font = new System.Drawing.Font("Consolas", 30F);
            this.n3.Location = new System.Drawing.Point(175, 108);
            this.n3.Name = "n3";
            this.n3.Size = new System.Drawing.Size(75, 75);
            this.n3.TabIndex = 5;
            this.n3.Text = "3";
            this.n3.UseVisualStyleBackColor = true;
            this.n3.Click += new System.EventHandler(this.n3_Click);
            // 
            // n4
            // 
            this.n4.Font = new System.Drawing.Font("Consolas", 30F);
            this.n4.Location = new System.Drawing.Point(13, 189);
            this.n4.Name = "n4";
            this.n4.Size = new System.Drawing.Size(75, 75);
            this.n4.TabIndex = 6;
            this.n4.Text = "4";
            this.n4.UseVisualStyleBackColor = true;
            this.n4.Click += new System.EventHandler(this.n4_Click);
            // 
            // n5
            // 
            this.n5.Font = new System.Drawing.Font("Consolas", 30F);
            this.n5.Location = new System.Drawing.Point(94, 189);
            this.n5.Name = "n5";
            this.n5.Size = new System.Drawing.Size(75, 75);
            this.n5.TabIndex = 7;
            this.n5.Text = "5";
            this.n5.UseVisualStyleBackColor = true;
            this.n5.Click += new System.EventHandler(this.n5_Click);
            // 
            // n6
            // 
            this.n6.Font = new System.Drawing.Font("Consolas", 30F);
            this.n6.Location = new System.Drawing.Point(175, 189);
            this.n6.Name = "n6";
            this.n6.Size = new System.Drawing.Size(75, 75);
            this.n6.TabIndex = 8;
            this.n6.Text = "6";
            this.n6.UseVisualStyleBackColor = true;
            this.n6.Click += new System.EventHandler(this.n6_Click);
            // 
            // n7
            // 
            this.n7.Font = new System.Drawing.Font("Consolas", 30F);
            this.n7.Location = new System.Drawing.Point(13, 270);
            this.n7.Name = "n7";
            this.n7.Size = new System.Drawing.Size(75, 75);
            this.n7.TabIndex = 9;
            this.n7.Text = "7";
            this.n7.UseVisualStyleBackColor = true;
            this.n7.Click += new System.EventHandler(this.n7_Click);
            // 
            // n8
            // 
            this.n8.Font = new System.Drawing.Font("Consolas", 30F);
            this.n8.Location = new System.Drawing.Point(94, 270);
            this.n8.Name = "n8";
            this.n8.Size = new System.Drawing.Size(75, 75);
            this.n8.TabIndex = 10;
            this.n8.Text = "8";
            this.n8.UseVisualStyleBackColor = true;
            this.n8.Click += new System.EventHandler(this.n8_Click);
            // 
            // n9
            // 
            this.n9.Font = new System.Drawing.Font("Consolas", 30F);
            this.n9.Location = new System.Drawing.Point(175, 270);
            this.n9.Name = "n9";
            this.n9.Size = new System.Drawing.Size(75, 75);
            this.n9.TabIndex = 11;
            this.n9.Text = "9";
            this.n9.UseVisualStyleBackColor = true;
            this.n9.Click += new System.EventHandler(this.n9_Click);
            // 
            // n0
            // 
            this.n0.Font = new System.Drawing.Font("Consolas", 30F);
            this.n0.Location = new System.Drawing.Point(13, 351);
            this.n0.Name = "n0";
            this.n0.Size = new System.Drawing.Size(75, 75);
            this.n0.TabIndex = 12;
            this.n0.Text = "0";
            this.n0.UseVisualStyleBackColor = true;
            this.n0.Click += new System.EventHandler(this.n0_Click);
            // 
            // point
            // 
            this.point.Font = new System.Drawing.Font("Consolas", 30F);
            this.point.Location = new System.Drawing.Point(94, 351);
            this.point.Name = "point";
            this.point.Size = new System.Drawing.Size(75, 75);
            this.point.TabIndex = 15;
            this.point.Text = ".";
            this.point.UseVisualStyleBackColor = true;
            this.point.Click += new System.EventHandler(this.point_Click);
            // 
            // plus
            // 
            this.plus.Font = new System.Drawing.Font("Consolas", 30F);
            this.plus.Location = new System.Drawing.Point(256, 108);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(75, 75);
            this.plus.TabIndex = 16;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // minus
            // 
            this.minus.Font = new System.Drawing.Font("Consolas", 30F);
            this.minus.Location = new System.Drawing.Point(256, 189);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(75, 75);
            this.minus.TabIndex = 17;
            this.minus.Text = "-";
            this.minus.UseVisualStyleBackColor = true;
            this.minus.Click += new System.EventHandler(this.minus_Click);
            // 
            // time
            // 
            this.time.Font = new System.Drawing.Font("Consolas", 30F);
            this.time.Location = new System.Drawing.Point(256, 270);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(75, 75);
            this.time.TabIndex = 18;
            this.time.Text = "*";
            this.time.UseVisualStyleBackColor = true;
            this.time.Click += new System.EventHandler(this.time_Click);
            // 
            // div
            // 
            this.div.Font = new System.Drawing.Font("Consolas", 30F);
            this.div.Location = new System.Drawing.Point(175, 351);
            this.div.Name = "div";
            this.div.Size = new System.Drawing.Size(75, 75);
            this.div.TabIndex = 19;
            this.div.Text = "/";
            this.div.UseVisualStyleBackColor = true;
            this.div.Click += new System.EventHandler(this.div_Click);
            // 
            // eq
            // 
            this.eq.Font = new System.Drawing.Font("Consolas", 30F);
            this.eq.Location = new System.Drawing.Point(256, 351);
            this.eq.Name = "eq";
            this.eq.Size = new System.Drawing.Size(75, 75);
            this.eq.TabIndex = 20;
            this.eq.Text = "=";
            this.eq.UseVisualStyleBackColor = true;
            this.eq.Click += new System.EventHandler(this.eq_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 450);
            this.Controls.Add(this.eq);
            this.Controls.Add(this.div);
            this.Controls.Add(this.time);
            this.Controls.Add(this.minus);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.point);
            this.Controls.Add(this.n0);
            this.Controls.Add(this.n9);
            this.Controls.Add(this.n8);
            this.Controls.Add(this.n7);
            this.Controls.Add(this.n6);
            this.Controls.Add(this.n5);
            this.Controls.Add(this.n4);
            this.Controls.Add(this.n3);
            this.Controls.Add(this.n2);
            this.Controls.Add(this.n1);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.backspace);
            this.Controls.Add(this.textBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button backspace;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button n1;
        private System.Windows.Forms.Button n2;
        private System.Windows.Forms.Button n3;
        private System.Windows.Forms.Button n4;
        private System.Windows.Forms.Button n5;
        private System.Windows.Forms.Button n6;
        private System.Windows.Forms.Button n7;
        private System.Windows.Forms.Button n8;
        private System.Windows.Forms.Button n9;
        private System.Windows.Forms.Button n0;
        private System.Windows.Forms.Button point;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button minus;
        private System.Windows.Forms.Button time;
        private System.Windows.Forms.Button div;
        private System.Windows.Forms.Button eq;
    }
}